package com.rufa.sdk;

import com.rufa.sdk.biz.api.EvidenceOpenApi;

/**
 * 下载文件
 */
public class RufaSdkDownload {

    public static void main(String[] args) {
        //先配置好信息再执行 ----》token、下载文件目录
        //配置地方：conf
        EvidenceOpenApi api = new EvidenceOpenApi();

        String fileid = "1543428C765B4E3160873"; //文件存证id编号

        api.download_zs(fileid);  // 安络司法证书下载

        api.download_rf(fileid);  //如法证书下载

        api.download(fileid);  //源文件下载
    }

}
