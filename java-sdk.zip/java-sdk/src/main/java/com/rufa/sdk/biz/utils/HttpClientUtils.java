package com.rufa.sdk.biz.utils;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 客户端请求辅助类
 */
public class HttpClientUtils {

    /**
     *  POST请求
     * @param url   请求链接
     * @param paramMap 请求参数
     * @return
     * @throws IOException
     */
    public static String doPost(String url, Map<String, String> paramMap,String contentType) throws IOException {
        String result = "";
        CloseableHttpResponse response = null;
        CloseableHttpClient httpclient = null;
        try {
            httpclient = HttpClients.createDefault();
            Builder builder = RequestConfig.custom();
            // 设置请求超时时间
            builder.setSocketTimeout(60000);
            // 设置传输超时时间
            builder.setConnectTimeout(60000);
            RequestConfig requestConfig = builder.build();
            HttpPost httpPost = new HttpPost(url);
            if(contentType != null){
                httpPost.addHeader("Content-Type", contentType);
            }
            httpPost.setConfig(requestConfig);
            List<NameValuePair> params = generateParam(paramMap);
            if (params.size() > 0) {
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params, "UTF-8");
                httpPost.setEntity(entity);
            }
            response = httpclient.execute(httpPost);
            if (null != response) {
                result = getHttpEntityContent(response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (response != null) {
                response.close();
            }
            if (httpclient != null) {
                httpclient.close();
            }
        }
        return result;
    }

    /**
     *  POST请求
     * @param url   请求链接
     * @param paramMap 请求参数
     * @return
     * @throws IOException
     */
    public static String doPost(String url, Map<String, String> paramMap,String authorization,String contentType) throws IOException {
        String result = "";
        CloseableHttpResponse response = null;
        CloseableHttpClient httpclient = null;
        try {
            httpclient = HttpClients.createDefault();
            Builder builder = RequestConfig.custom();
            // 设置请求超时时间
            builder.setSocketTimeout(60000);
            // 设置传输超时时间
            builder.setConnectTimeout(60000);
            RequestConfig requestConfig = builder.build();
            HttpPost httpPost = new HttpPost(url);
            if(contentType != null){
                httpPost.addHeader("Content-Type", contentType);
            }
            httpPost.setHeader("Authorization",  authorization);
            httpPost.setConfig(requestConfig);
            List<NameValuePair> params = generateParam(paramMap);
            if (params.size() > 0) {
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params, "UTF-8");
                httpPost.setEntity(entity);
            }
            response = httpclient.execute(httpPost);
            if (null != response) {
                result = getHttpEntityContent(response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (response != null) {
                response.close();
            }
            if (httpclient != null) {
                httpclient.close();
            }
        }
        return result;
    }

    /**
     *  POST请求
     * @param url   请求链接
     * @param json 请求参数
     * @return
     * @throws IOException
     */
    public static String doPost(String url, String json) throws IOException {
        String result = "";
        CloseableHttpResponse response = null;
        CloseableHttpClient httpclient = null;
        try {
            httpclient = HttpClients.createDefault();
            Builder builder = RequestConfig.custom();
            // 设置请求超时时间
            builder.setSocketTimeout(60000);
            // 设置传输超时时间
            builder.setConnectTimeout(60000);
            RequestConfig requestConfig = builder.build();
            HttpPost httpPost = new HttpPost(url);
            httpPost.setConfig(requestConfig);

            StringEntity entity = new StringEntity(json);
            entity.setContentEncoding("UTF-8");
            entity.setContentType("application/json");//发送json数据需要设置contentType
            httpPost.setEntity(entity);

            response = httpclient.execute(httpPost);
            if (null != response) {
                result = getHttpEntityContent(response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (response != null) {
                response.close();
            }
            if (httpclient != null) {
                httpclient.close();
            }
        }
        return result;
    }

    /**
     *  Post请求获取文件
     * @param url 请求链接
     * @param authorization 请求头凭证
     * @param downloadPath 下载文件包含名称地址
     * @return
     */
    public static boolean doPostFile(String url,String authorization,String downloadPath,Map<String, String> paramMap) {
        boolean res = false;
        CloseableHttpClient httpCilent2 = HttpClients.createDefault();
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(5000)   //设置连接超时时间
                .setConnectionRequestTimeout(5000) // 设置请求超时时间
                .setSocketTimeout(5000)
                .setRedirectsEnabled(true)//默认允许自动重定向
                .build();
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(requestConfig);

        //httpGet2.setHeader("Content-Type", "application/json");
        httpPost.setHeader("Authorization",  authorization);

        try {
            List<NameValuePair> params = generateParam(paramMap);
            if (params != null && params.size() > 0) {
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params, "UTF-8");
                httpPost.setEntity(entity);
            }

            HttpResponse httpResponse = httpCilent2.execute(httpPost);
            if(httpResponse.getStatusLine().getStatusCode() == 200){
                HttpEntity entity = httpResponse.getEntity();
                //srtResult = EntityUtils.toString(httpResponse.getEntity());//获得返回的结果

                //判断返回结果是html，还是文件流
                InputStream inStream = entity.getContent();

                //C:/Users/MIAO/Desktop/Response.jpg
                FileOutputStream fw = new FileOutputStream(downloadPath, false);
                int b = inStream.read();
                while (b != -1) {
                    fw.write(b);
                    b = inStream.read();
                }
                res = true;
                fw.close();
                EntityUtils.consume(entity);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                httpCilent2.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return res;
    }

    /**
     *  GET请求获取文件
     * @param url 请求链接
     * @param authorization 请求头凭证
     * @param downloadPath 下载文件包含名称地址
     * @return
     */
    public static boolean doGetFile(String url,String authorization,String downloadPath) {
        boolean res = false;
        CloseableHttpClient httpCilent2 = HttpClients.createDefault();
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(5000)   //设置连接超时时间
                .setConnectionRequestTimeout(5000) // 设置请求超时时间
                .setSocketTimeout(5000)
                .setRedirectsEnabled(true)//默认允许自动重定向
                .build();
        HttpGet httpGet2 = new HttpGet(url);
        httpGet2.setConfig(requestConfig);

        //httpGet2.setHeader("Content-Type", "application/json");
        httpGet2.setHeader("Authorization",  authorization);

        try {
            HttpResponse httpResponse = httpCilent2.execute(httpGet2);
            if(httpResponse.getStatusLine().getStatusCode() == 200){
                HttpEntity entity = httpResponse.getEntity();
                //srtResult = EntityUtils.toString(httpResponse.getEntity());//获得返回的结果

                String headerValue = httpResponse.getFirstHeader("Content-Disposition").getValue();
                System.out.println("响应头：" + headerValue);

                String filename = headerValue.split("filename=")[1];
               // filename = URLDecoder.decode(filename, "UTF-8" );
                filename =  new String(filename.getBytes("ISO8859-1"), "gb2312");
                System.out.println("文件名称：" + filename );

                //String headerValue = httpResponse.getHeader("Content-Disposition");
                //ContentDisposition disposition = ContentDisposition.parse(headerValue);
                //String filename = disposition.getFilename();
               // filename = URLDecoder.decode(filename, "UTF-8" );

                //判断返回结果是html，还是文件流
                InputStream inStream = entity.getContent();

                //C:/Users/MIAO/Desktop/Response.jpg
                FileOutputStream fw = new FileOutputStream(downloadPath + filename, false);
                int b = inStream.read();
                while (b != -1) {
                    fw.write(b);
                    b = inStream.read();
                }
                res = true;
                fw.close();
                EntityUtils.consume(entity);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                httpCilent2.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return res;
    }


    private static List<NameValuePair> generateParam(Map<String, String> paramMap) {
        List<NameValuePair> list = new ArrayList<>();
        if(paramMap != null && paramMap.size() > 0) {
            Iterator<String> iters = paramMap.keySet().iterator();
            while (iters.hasNext()) {
                String key = iters.next();
                list.add(new BasicNameValuePair(key, paramMap.get(key)));
            }
        }
        return list;
    }

    private static String getHttpEntityContent(HttpResponse response) throws IOException{
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            StringBuilder sb = new StringBuilder();
            InputStream is = entity.getContent();
            byte[] bytes = new byte[1024];
            int count = 0;
            while ((count = is.read(bytes)) > 0) {
                sb.append(new String(bytes, 0, count, "UTF-8"));
            }
            return sb.toString();
        }
        return "";
    }

}
