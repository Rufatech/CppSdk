package com.rufa.sdk.biz.utils;

import com.rufa.sdk.biz.model.FileInfoEntity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 文件处理工具类
 */
public class FileUtils {
    /**
     * 获取指定目录下所有文件（不包含下级目录）
     * @param path 文件夹目录
     * @return
     */
    public static List<FileInfoEntity> getFiles(String path) {
        List<FileInfoEntity> fileEntity = new ArrayList<>();

        File file = new File(path);
        File[] tempList = file.listFiles();
        for (int i = 0; i < tempList.length; i++) {
            if (tempList[i].isFile()) {
                FileInfoEntity entity = new FileInfoEntity();
                entity.setFile(tempList[i]);
                entity.setFileName(tempList[i].getName());
                fileEntity.add(entity);
            }

            //if (tempList[i].isDirectory()) {
                //这里就不递归了，
            //}
        }
        return fileEntity;
    }
}
