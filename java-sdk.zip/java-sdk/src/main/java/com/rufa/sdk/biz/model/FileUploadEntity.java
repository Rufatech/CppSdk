package com.rufa.sdk.biz.model;

import lombok.Data;

/**
 * 文件存证信息
 */
@Data
public class FileUploadEntity {

    private String filename;  //文件名称    财税.docx

    private String applyName; //应用名称    对应平台上创建的应用

    private String orderNo; //业务单号      自定义，方便管理

    /**
     * 文件分类
     * 身份信息: 1；
     * 申请信息: 2 ；
     * 合同文件: 3 ;
     * 放款信息: 4 ;
     * 回款信息: 5 ;
     * 催收信息: 6 ;
     * 其他: 7
     */
    private Integer fileTypeId; //文件分类

    /**
     * 文件标签
     * 【身份信息==
     * 基本信息:  11 ;
     * 平台账号:  12 ;
     * 认证信息（活体检测、身份证照片、短信/邮件验证码记录等）:  13 ;
     *  银行卡信息: 14 ;
     *  其他:  15 】
     *
     *  【申请信息==
     * 授信记录:  21 ;
     * 申请记录:  22 ;
     *  其他:  23  】
     *
     *  【合同文件：==
     * 贷款合同:  31 ;
     * 服务协议:  32 ;
     * 用户协议:  33 ;
     *  其他:  34】
     *
     * 【放款信息：==
     * 放款记录:  41;
     * 放款凭证:  42 ;
     * 其他:  43 】
     *
     * 【回款信息：==
     * 回款记录:  51;
     * 回款凭证:  52 ;
     * 其他:  53】
     *
     * 【催收信息：==
     * 催收记录:  61 ;
     *  其他:  62 】
     *
     * 【其他记录 ： 其他:  71 】
     */
    private Integer fileLabelNo;  //文件标签


}
