package com.rufa.sdk.biz.model;

import lombok.Data;

import java.io.File;

/**
 * 文件实体信息
 */
@Data
public class FileInfoEntity {

    private  String fileName;  //文件名称，包含后缀

    private File file;  //文件对象

}
