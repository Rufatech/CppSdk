package com.rufa.sdk;

import com.rufa.sdk.biz.api.EvidenceOpenApi;

/**
 * 文件存证
 */
public class RufaSdkUpload {
	
	public static void main(String[] args) {
		//先配置好信息再执行 ----》token、上传文件目录、文件标签
		//配置地方：conf
		EvidenceOpenApi api = new EvidenceOpenApi();
		api.upload();

	}


}
