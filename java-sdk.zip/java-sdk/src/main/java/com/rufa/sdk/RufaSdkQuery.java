package com.rufa.sdk;

import com.rufa.sdk.biz.api.EvidenceOpenApi;

/**
 * 查询存证详细信息
 */
public class RufaSdkQuery {

    public static void main(String[] args) {

        EvidenceOpenApi api = new EvidenceOpenApi();
        String fileId = "1543428C765B4E3160873";

        api.query(fileId);

    }
}
