package com.rufa.sdk;

import com.rufa.sdk.biz.api.EvidenceOpenApi;

/**
 * 存证开放校验
 */
public class RufaSdkVerify {
    public static void main(String[] args) {

        EvidenceOpenApi api = new EvidenceOpenApi();
        String transHash = "0x3f16785e4f771811c5979bdbcacb85d5fac76c676b2a6dd3bd308a1871492d43";
        String fileId = "68839876DCD3313160869";
        String fileSha256 = "";
        api.verify(transHash,fileId,fileSha256);

    }
}
