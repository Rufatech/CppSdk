package com.rufa.sdk.biz.conf;

/**
 * 相关配置常量
 */
public class Constant {

	 /**
	  * appID 商家id
	  */
	public final static String  APP_ID  = "lCajM211";

	/**
	 * secret 鉴权密钥
	 */

	public final static String  ACCESS_SECRET = "cbf4ad990d22eba2ee13485530636e9cb5237f38";

	/**
	 * 上链文件目录
	 */

	public final static String  FILE_PATH = "F:/upload";

	/**
	 * 下载文件目录
	 */
	public final static String  DOWNLOAD_PATH = "F:/download";

	/**
	 * 获取认证链接
	 */
	public final static String APPLOGIN_URL = "https://open.rufayun.com/openapi/evidence/applogin";

	/**
	 * 文件存证链接
	 */
	public final static String UPLOAD_URL = "https://open.rufayun.com/openapi/evidence/upload";

	/**
	 * 如法证书下载链接
	 */
	public final static String RF_D_URL = "https://open.rufayun.com/openapi/evidence/rf/d/";

	/**
	 * 安络司法证书下载链接
	 */
	public final static String ZS_D_URL = "https://open.rufayun.com/openapi/evidence/zs/d/";

	/**
	 * 源文件下载链接
	 */
	public final static String D_URL = "https://open.rufayun.com/openapi/evidence/d/";

	/**
	 * 查询存证详细信息
	 */
	public final static String QUERY_URL = "https://open.rufayun.com/openapi/evidence/info";

	/**
	 * 存证开放校验
	 */
	public final static String VERIFY_URL = "https://open.rufayun.com/openapi/evidence/verify";

}
