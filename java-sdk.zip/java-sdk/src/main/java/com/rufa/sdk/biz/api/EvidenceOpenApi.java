package com.rufa.sdk.biz.api;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.*;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.rufa.sdk.biz.conf.Constant;
import com.rufa.sdk.biz.conf.FileUploadConf;
import com.rufa.sdk.biz.model.*;


import com.rufa.sdk.biz.utils.FileUtils;
import com.rufa.sdk.biz.utils.HttpClientUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.client.config.RequestConfig.Builder;

/**
 * 对接业务
 */
public class EvidenceOpenApi  {

    private static Long current_expires = 0L; //凭证有效时间，单位：秒

    private static Long current_createtime = 0L;  //记录当前的时间   单位：毫秒

    private static String current_accessToken = null;   //当前登录凭证

    /**
     * 获取认证
     */
    public String applogin(){
        String accessToken = null;
        try {
            if(StringUtils.isNotBlank(current_accessToken) && current_createtime  != null && current_createtime > 0){
                Long expiresTemp = (new  Date().getTime() - current_createtime) / 1000; //秒
                if((current_expires - expiresTemp) > 0){
                    return current_accessToken;
                }
            }
            Date nowTime  = new Date();

            Map<String, String> params = new HashMap<>();
            params.put("appId",Constant.APP_ID);
            params.put("accessSecret",Constant.ACCESS_SECRET);
            String responseString = HttpClientUtils.doPost(Constant.APPLOGIN_URL, JSON.toJSONString(params));
            if (StringUtils.isNotBlank(responseString)) {
                // 转为ＪＳＯＮ
                JSONObject resultJson = JSONObject.parseObject(responseString);
                Integer code = resultJson.getInteger("code");
                String msg = resultJson.getString("msg");
                if(code != null && code==0 ){
                    JSONObject dataJson = resultJson.getJSONObject("data");
                    accessToken = dataJson.getString("accessToken");
                    Long expires = dataJson.getLong("expires"); //凭证有效时间，单位：秒
                    if(expires != null){
                        current_expires = expires;
                        current_accessToken = accessToken;
                        current_createtime = nowTime.getTime();
                    }
                    System.out.println("成功获取有效凭证时间:" + expires + "；消息：" + msg );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return accessToken;
    }

    /**
     * 文件存证
     */
    public void upload(){
        CloseableHttpClient httpclient = null;
        CloseableHttpResponse response = null;
        try {
            //要上链的文件夹下的文件
            List<FileInfoEntity> fileEntityList = FileUtils.getFiles(Constant.FILE_PATH);
            if(fileEntityList == null || fileEntityList.size()==0){
                System.out.println("没有找到相应文件要上链");
                return;
            }

            httpclient = HttpClients.createDefault();
            HttpPost httpPost = new HttpPost(Constant.UPLOAD_URL);

            //获取鉴权
            String accessSecret = applogin();
            if(StringUtils.isBlank(accessSecret)){
                System.out.println("获取不到权限");
                return;
            }
            httpPost.setHeader("Authorization",  accessSecret);

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setCharset(Charset.forName("utf-8")); //处理乱码问题
            builder.setMode(HttpMultipartMode.RFC6532);

            //二进制文件
            for(FileInfoEntity fileEntity : fileEntityList){
                //application_octet_stream  请求头application/octet-stream(二进制流，不知道文件类型)
                builder.addBinaryBody("file", fileEntity.getFile(), ContentType.APPLICATION_OCTET_STREAM, fileEntity.getFileName());
            }

            //表单参数
            if(FileUploadConf.TYPE == 1) {
                builder.addPart("type", new StringBody("1", ContentType.TEXT_PLAIN)); //文件分类 Type 0

                String fileInfo = JSON.toJSONString(FileUploadConf.getFileUploadEntityList());
                ContentType contentType = ContentType.create(ContentType.TEXT_PLAIN.getMimeType(), "UTF-8");
                builder.addPart("fileInfo", new StringBody(fileInfo, contentType));  //文件关联信息
            }else{
                builder.addPart("type", new StringBody("0", ContentType.TEXT_PLAIN)); //文件分类 Type 0

                String fileInfo = JSON.toJSONString(FileUploadConf.getFileUploadEntity());
                ContentType contentType = ContentType.create(ContentType.TEXT_PLAIN.getMimeType(), "UTF-8");
                builder.addPart("fileInfo", new StringBody(fileInfo, contentType));  //文件关联信息
            }

            Builder builderConfig = RequestConfig.custom();
            // 设置请求超时时间
            builderConfig.setSocketTimeout(600000);
            // 设置传输超时时间
            builderConfig.setConnectTimeout(600000);
            RequestConfig requestConfig = builderConfig.build();
//            httpPost.setConfig(requestConfig);

            HttpEntity reqEntity = builder.build();
            httpPost.setEntity(reqEntity);
            response = httpclient.execute(httpPost);

            //响应状态
            int code = response.getStatusLine().getStatusCode();
            String info = response.getStatusLine().getReasonPhrase();
            if(code != 200) {
                System.out.println(String.valueOf(code) + "&" + info);
                return;
            }
            System.out.println("----------------------------------------");
            System.out.println(response.getStatusLine()); //打印响应状态

            //获取响应对象
            String content =  getHttpEntityContent(response);

            System.out.println("Response: " + content);

            //销毁
            //HttpEntity entity = response.getEntity();
            //EntityUtils.consume(entity);
        }catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if(response != null){
                    response.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if(httpclient != null){
                    httpclient.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static String getHttpEntityContent(HttpResponse response) throws IOException{
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            StringBuilder sb = new StringBuilder();
            InputStream is = entity.getContent();
            byte[] bytes = new byte[1024];
            int count = 0;
            while ((count = is.read(bytes)) > 0) {
                sb.append(new String(bytes, 0, count, "UTF-8"));
            }
            return sb.toString();
        }
        return "";
    }

    /**
     * 源文件下载
     */
    public void download(String fileid){
        //获取鉴权
        String accessSecret = applogin();
        if(StringUtils.isBlank(accessSecret)){
            System.out.println("获取不到权限");
            return;
        }
        String url = Constant.D_URL + fileid;
        String path = Constant.DOWNLOAD_PATH + "/";
        //String path = Constant.DOWNLOAD_PATH + "/" + fileid + "d";
        HttpClientUtils.doGetFile(url,accessSecret,path);
    }

    /**
     * 如法证书下载
     */
    public void download_rf(String fileid){
        //获取鉴权
        String accessSecret = applogin();
        if(StringUtils.isBlank(accessSecret)){
            System.out.println("获取不到权限");
            return;
        }
        String url = Constant.RF_D_URL + fileid;
        String path = Constant.DOWNLOAD_PATH + "/";
        //String path = Constant.DOWNLOAD_PATH + "/" + fileid + "rf.pdf";
        HttpClientUtils.doGetFile(url,accessSecret,path);
    }

    /**
     * 安络司法证书下载
     */
    public void download_zs(String fileid){
        //获取鉴权
        String accessSecret = applogin();
        if(StringUtils.isBlank(accessSecret)){
            System.out.println("获取不到权限");
            return;
        }
        String url = Constant.ZS_D_URL + fileid;
        String path = Constant.DOWNLOAD_PATH + "/";
        //String path = Constant.DOWNLOAD_PATH + "/" + fileid + "zs.pdf";
        HttpClientUtils.doGetFile(url,accessSecret,path);
    }

    /**
     * 查询存证详细信息
     */
    public void query(String fileId){
        String url = Constant.QUERY_URL;
        Map<String,String> parm = new HashMap<>();
        parm.put("fileId",fileId);
        try {
            //获取鉴权
            String accessSecret = applogin();
            if(StringUtils.isBlank(accessSecret)){
                System.out.println("获取不到权限");
                return;
            }

            String res = HttpClientUtils.doPost(url,parm,accessSecret,null);
            System.out.println("结果:" + res);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 存证开放校验
     */
    public void verify(String transHash,String fileId,String fileSha256){
        String url = Constant.VERIFY_URL;
        Map<String,String> parm = new HashMap<>();
        parm.put("transHash",transHash);
        parm.put("fileId",fileId);
        parm.put("fileSha256",fileSha256);
        try {
            String res = HttpClientUtils.doPost(url,parm,null);
            System.out.println("校验结果:" + res);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}