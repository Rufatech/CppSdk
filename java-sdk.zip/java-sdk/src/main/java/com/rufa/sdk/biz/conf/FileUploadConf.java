package com.rufa.sdk.biz.conf;

import com.rufa.sdk.biz.model.FileUploadEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * 文件匹配标签
 */
public class FileUploadConf {

    public static final Integer TYPE = 0;  //确定文件分类

    /**
     * 文件分类 Type 0
     * fileInfo 为 json
     * @return
     */
    public static FileUploadEntity getFileUploadEntity(){
        FileUploadEntity fe = new FileUploadEntity();
        //fe.setFilename("财税.docx"); //文件名称  type 0 可不填
        fe.setApplyName("万胜分期"); //应用名称
        fe.setOrderNo("202012281508"); //业务单号
        fe.setFileTypeId(4); //文件分类
        fe.setFileLabelNo(41);

        return fe;
    }

    /**
     * 文件分类 Type 1
     * fileInfo 为 jsonArray
     * @return
     */
    public static List<FileUploadEntity> getFileUploadEntityList(){
        List<FileUploadEntity> feList = new ArrayList<>();

        //1
        FileUploadEntity f1 = new FileUploadEntity();
        f1.setFilename("财税.docx"); //文件名称
        f1.setApplyName("京东金融"); //应用名称
        f1.setOrderNo("JinRon226666"); //业务单号
        f1.setFileTypeId(4); //文件分类
        f1.setFileLabelNo(41);
        feList.add(f1);

        //2
        FileUploadEntity f2 = new FileUploadEntity();
        f2.setFilename("2020合同.txt"); //文件名称
        f2.setApplyName("京东金融"); //应用名称
        f2.setOrderNo("JinRon447777"); //业务单号
        f2.setFileTypeId(3); //文件分类
        f2.setFileLabelNo(31);
        feList.add(f2);

        //3
        FileUploadEntity f3 = new FileUploadEntity();
        f3.setFilename("受理通知书.docx"); //文件名称
        f3.setApplyName("京东金融"); //应用名称
        f3.setOrderNo("JinRon558888"); //业务单号
        f3.setFileTypeId(2); //文件分类
        f3.setFileLabelNo(22);
        feList.add(f3);

        return feList;
    }
}
